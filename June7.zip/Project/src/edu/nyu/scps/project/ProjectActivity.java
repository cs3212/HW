package edu.nyu.scps.project;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

public class ProjectActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		//findViewById cannot be called before setContentView.
		TextView textView = (TextView)findViewById(R.id.textView);

		if (textView == null) {
			Toast.makeText(this, "could not find the TextView", Toast.LENGTH_LONG).show();
		} else {
			textView.setText("This is a Textview display");
		}
        
		Toast.makeText(this, "This is a toast display", Toast.LENGTH_SHORT).show();
		
		Log.d("myTag", "This is a log.d display");
        
//		WindowManager manager = (WindowManager)getSystemService(Context.WINDOW_SERVICE);
//		Display display = manager.getDefaultDisplay();
	
//		System.out.println("width == "  + display.getWidth());
//		System.out.println("height == " + display.getHeight());
		
//		Toast.makeText(this, Integer.toString("width == " + display.getWidth()), Toast.LENGTH_LONG).show();
//		Toast.makeText(this, Integer.toString("height == " + display.getHeight()), Toast.LENGTH_LONG).show();

        
    }
}